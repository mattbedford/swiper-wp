<?php
/**
 * Plugin Name: Swiper WP
 * Description: A tool to use in conjunction with ACF Pro to create a custom SwiperJS block.
 * Version:     2.0.0
 * Author:      Matt Bedford | Ulisse Snc
 * Text Domain: swiper-wp
 * License:     GPL v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */

namespace SwiperWP;

include_once 'blocks/slider-block/swiper-wp.php';
include_once 'blocks/slider-block/init.php';
include_once 'blocks/slider-block/slider.php';

new Register();